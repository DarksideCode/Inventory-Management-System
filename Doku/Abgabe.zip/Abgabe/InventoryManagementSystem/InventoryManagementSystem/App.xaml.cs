﻿using System.Windows;

namespace InventoryManagementSystem
{
    /// <summary>
    /// Interaktionslogik für "App.xaml"
    /// </summary>
    public partial class App : Application
    {
    }
}
